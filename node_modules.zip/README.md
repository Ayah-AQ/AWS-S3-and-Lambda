# AWS-S3-and-Lambda

## PR
https://github.com/Ayah-AQ/AWS-S3-and-Lambda/pulls

## Deployed link"
https://awsimgg.s3.amazonaws.com/images.json

## descriptions

>  how to use lambda

* Compress these into .Zip file:
- index.js
- package-lock.json
- package.json
- node_modules

* To AWS:
- Create an S3 Bucket with read permissions on then upload into it the previous zip file.
- Set up the Lambda Function then upload the compressed file from s3 location.


